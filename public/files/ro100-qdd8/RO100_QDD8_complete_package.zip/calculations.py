"""Independent SI/mm hand-calculation reproduction; no FEA or fatigue certification."""
import math,json
pi=math.pi;m=.65;b=20;z=[15,45,105];alpha=math.radians(25);a=19.5
K=1.5*1.25*1.1*1.15;Kroot=1.35;E=210000;nu=.3

def inv(r,rb):
 v=math.sqrt(max(0,(r/rb)**2-1));return v-math.atan(v)
def lewis(n):
 rp=m*n/2;rb=rp*math.cos(alpha);ra=rp+m;rf=rp-1.25*m
 vals=[]
 for j in range(2001):
  r=rf+(ra-rf)*j/2002;h=ra-r
  half=pi/(2*n)-.01/rp+inv(rp,rb)-inv(max(r,rb),rb);t=2*r*math.sin(half)
  vals.append((t*t/(6*h*m),r,t,h))
 return min(vals)
Ys=lewis(15);Yp=lewis(45)
rs,rp,rr=[m*n/2 for n in z];rbs,rbp,rbr=[r*math.cos(alpha) for r in [rs,rp,rr]]
contact_ext=(math.sqrt((rs+m)**2-rbs*rbs)+math.sqrt((rp+m)**2-rbp*rbp)-a*math.sin(alpha))/(pi*m*math.cos(alpha))
contact_int=(math.sqrt((rp+m)**2-rbp*rbp)-math.sqrt((rr-m)**2-rbr*rbr)+a*math.sin(alpha))/(pi*m*math.cos(alpha))
Rext=(rs*math.sin(alpha)*rp*math.sin(alpha))/(rs*math.sin(alpha)+rp*math.sin(alpha))
Rint=1/(1/(rp*math.sin(alpha))-1/(rr*math.sin(alpha)))
Eprime=E/(2*(1-nu*nu))
result=dict(ratio=1+105/15,module=m,pressure_angle_deg=25,teeth=z,center_distance=a,
 planet_gap=2*a*math.sin(pi/3)-(45+2)*m,ring_rim=(74-(105+2.5)*m)/2,
 contact_ratio_external=contact_ext,contact_ratio_internal=contact_int,
 Ysun=Ys,Yplanet=Yp,load_factor=K,root_factor=Kroot)
rows=[]
for T in [4,5,6,8,12]:
 Ft=2*T*1000/(3*(m*15));F=K*Ft;Fn=F/math.cos(alpha)
 # Lewis from first principles, plus conservative direct normal stress.
 sig=Kroot*(F/(b*m*Ys[0])+Fn/(b*Ys[2]))
 tau_sun=16*(T*1000*1.5)*1.5/(pi*(m*(15-2.5))**3)
 sig_comb=math.sqrt(sig**2+3*tau_sun**2)
 sigp=Kroot*(F/(b*m*Yp[0])+Fn/(b*Yp[2]))
 ph=math.sqrt(Fn*Eprime/(pi*b*Rext)); phr=math.sqrt(Fn*Eprime/(pi*b*Rint))
 pin=2*F;L=25;d=8;I=pi*d**4/64
 Mpin=pin*L/4;sigpin=32*Mpin/(pi*d**3);taupin=pin/(2*pi*d*d/4)
 rows.append(dict(Tmotor=T,Tout=.94*8*T,Ft_nom=Ft,Ft_design=F,sun_root_MPa=sig,planet_root_MPa=sigp,
 root_static_margin_900=900/sig,sun_combined_torsion_MPa=sig_comb,sun_combined_margin_900=900/sig_comb,pitch_Hertz_MPa=ph,ring_pitch_Hertz_MPa=phr,
 pin_N=pin,pin_vm_MPa=math.sqrt(sigpin**2+3*taupin**2),pin_deflection_mm=pin*L**3/(48*E*I),
 bearing_static_margin=5850/pin,copper_loss_W=(T/.53)**2))
result['torque_cases']=rows
# Spectrum: peak6Nm 10%, rated4Nm 30%, light1Nm 60%; equal 800rpm motor during motion.
Kd=1.25*1.1*1.15;expo=10/3
loads=[4*T*1000/(3*9.75)*Kd for T in [6,4,1]]
Peq=sum(f*p**expo for f,p in zip([.1,.3,.6],loads))**(1/expo)
result['planet_life']=dict(Peq_N=Peq,nrel_rpm=(800-100)/3,L10h=(5010/Peq)**expo*1e6/(60*((800-100)/3)))
P0=1000+2*50000/67+.44*500
Pc=300+2*15000/67+.45*150
result['output_bearing']=dict(P0=P0,static_margin=8680/P0,Pc=Pc,L10h_conservative_cubic=(5680/(1.5*Pc))**3*1e6/(60*100))
result['input_bearing']=dict(P_N=300,C=3450,C0=1370,L10h=(3450/300)**3*1e6/(60*2000),static_margin=1370/300)
# Thermal network: steel axial path to front flange; convection budget, not validated temperatures.
Asteel=pi*((77.9/2000)**2-(74.04/2000)**2)
Rsteel=.014/(170*(Asteel-21e-6))
Afin=6*2*pi*(.07**2-.066**2)
Abase=pi*.132*(.0385-6*.0015)+pi*(.066**2-.03175**2)+pi*(.066**2-.0042**2)
Aeff=Abase+.9*Afin
Trms=math.sqrt(.1*36+.3*16+.6)
Pcu=(Trms/.53)**2;gear=.06*(.1*6+.3*4+.6*1)*800*2*pi/60;Ptot=Pcu+gear+15
result['thermal']=dict(R_sleeve=Rsteel,Aeff=Aeff,R_internal_assumed=Rsteel+.3+.011+.10,
 Rair_natural=1/(8*Aeff),Rair_forced=1/(60*Aeff),Trms=Trms,Pcu=Pcu,Pgear=gear,Ptotal=Ptot,
 required_R_winding_ambient=60/Ptot)
# Joint suitability example, not a requirement supplied by user.
result['robot_example']=dict(mass_kg=60,support_legs=2,dynamic_factor=1.5,lever_m=.10,Tjoint=60*9.81*1.5*.10/2)
# Bolt stresses use preload separately; transmitted load never assigned to threads alone when friction holds.
def bolts(n,r,d,As,preload,T,Fax,M,proof,mu=.12):
 Q=T*1000/(n*r);P=Fax/n+2*M*1000/(n*r)
 return dict(shear_per_bolt_N=Q,tension_external_N=P,slip_torque_Nm=n*mu*preload*r/1000,
 shear_MPa=Q/As,combined_MPa=math.sqrt(((preload+.25*P)/As)**2+3*(Q/As)**2),proof_MPa=proof,
 install_torque_Nm=.2*preload*d/1000)
result['bolts']={
 'output_6M5':bolts(6,24,5,14.2,8500,96,500,50,970),
 'ring_8M3':bolts(8,41,3,5.03,2500,84,0,0,970),
 'housing_8M4':bolts(8,60.5,4,8.78,4000,96,500,50,830),
 'rotor_6M3':bolts(6,12,3,5.03,1800,6,0,0,970),
 'leg_6M5':bolts(6,20,5,14.2,8500,96,500,50,970)}
# Adhesive shear from T=tau*(2*pi*r*L)*r.
result['bonds']=dict(stator_shear_MPa=12000/(2*pi*39**2*20),rotor_shear_MPa=12000/(2*pi*54.15**2*24),
 rotor_bond_centrifugal_pressure_MPa=.19*(2550*2*pi/60)**2/(2*pi*.024)/1e6)
result['reflected_rotor_inertia']=5290*1e-7*8**2
if __name__=='__main__':
 from pathlib import Path
 path=Path(__file__).resolve().parent/'calculations.json'
 path.write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
