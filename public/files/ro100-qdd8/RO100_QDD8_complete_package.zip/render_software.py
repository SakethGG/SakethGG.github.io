import json,subprocess,numpy as np
from pathlib import Path
from PIL import Image,ImageDraw,ImageFont
P=Path(__file__).resolve().parent;mesh=json.load(open(P/'preview_mesh.json'))
cam=np.array([1.3,-1.8,3.4]);cam/=np.linalg.norm(cam);u=np.cross([0,0,1],cam);u/=np.linalg.norm(u);v=np.cross(cam,u)
for mode,fn in [('full','assembly_preview.png'),('open','gearbox_cutaway.png')]:
 allxyz=[];allcol=[]
 for o in mesh:
  n=o['name']
  if mode=='open' and (n.startswith(('01B_','01C_','01D_','07_','14_','15_','16_','17_','18_','19_','20_','21_','22_','23_','25_','26_','27_','28_','29_','30_','31_','32_')) or n.startswith('13_608_front')):continue
  xyz=np.array(o['vertices'])[np.array(o['faces'])];norm=np.cross(xyz[:,1]-xyz[:,0],xyz[:,2]-xyz[:,0]);norm/=np.maximum(np.linalg.norm(norm,axis=1)[:,None],1e-15);norm*=np.where(norm@cam<0,-1,1)[:,None]
  light=np.array([-.2,-.5,.85]);light/=np.linalg.norm(light);shade=.5+.5*np.maximum(norm@light,0)
  allxyz.append(xyz);allcol.append(np.array(o['color'])[None,:]*shade[:,None])
 xyz=np.concatenate(allxyz);co=np.concatenate(allcol);px=xyz@u;py=xyz@v;pz=xyz@cam
 scale=min(2480/(px.max()-px.min()),1700/(py.max()-py.min()));sx=(px-(px.max()+px.min())/2)*scale+1400;sy=-(py-(py.max()+py.min())/2)*scale+1100
 data=np.column_stack([np.stack([sx,sy,pz],axis=-1).reshape((-1,9)),co]).astype(np.float32)
 with open(P/'triangles.bin','wb') as f:np.array([len(data)],dtype=np.int64).tofile(f);data.tofile(f)
 subprocess.run([str(P/'raster'),str(P/'triangles.bin'),str(P/'render.ppm')],check=True)
 im=Image.open(P/'render.ppm').resize((1400,1050),Image.Resampling.LANCZOS);draw=ImageDraw.Draw(im)
 font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf',28);draw.text((30,20),'RO100 / QDD-8  |  '+('ASSEMBLY' if mode=='full' else 'GEAR TRAIN / COVERS REMOVED'),font=font,fill='#14384e')
 font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',17);draw.text((30,1010),'R1 concept • direct CAD rendering • motor and bearing internals simplified',font=font,fill='#476070');im.save(P/fn)
 print(fn, len(data),flush=True)
