#include <fstream>
#include <vector>
#include <cmath>
#include <algorithm>
#include <cstdint>
int main(int argc,char**argv){int W=2800,H=2100;std::ifstream in(argv[1],std::ios::binary);int64_t n;in.read((char*)&n,8);std::vector<float> z(W*H,-1e20);std::vector<unsigned char> c(W*H*3);for(int i=0;i<W*H;i++){c[3*i]=243;c[3*i+1]=247;c[3*i+2]=251;}float t[12];for(int64_t k=0;k<n;k++){in.read((char*)t,48);float x0=t[0],y0=t[1],x1=t[3],y1=t[4],x2=t[6],y2=t[7];float den=(y1-y2)*(x0-x2)+(x2-x1)*(y0-y2);if(fabs(den)<1e-8)continue;int lx=std::max(0,(int)floor(std::min({x0,x1,x2}))),hx=std::min(W-1,(int)ceil(std::max({x0,x1,x2})));int ly=std::max(0,(int)floor(std::min({y0,y1,y2}))),hy=std::min(H-1,(int)ceil(std::max({y0,y1,y2})));for(int y=ly;y<=hy;y++)for(int x=lx;x<=hx;x++){float a=((y1-y2)*(x+.5f-x2)+(x2-x1)*(y+.5f-y2))/den,b=((y2-y0)*(x+.5f-x2)+(x0-x2)*(y+.5f-y2))/den,cc=1-a-b;if(a<-.00001||b<-.00001||cc<-.00001)continue;float d=a*t[2]+b*t[5]+cc*t[8];int i=y*W+x;if(d>z[i]){z[i]=d;for(int q=0;q<3;q++)c[i*3+q]=(unsigned char)std::clamp(t[9+q]*255.f,0.f,255.f);}}}std::ofstream out(argv[2],std::ios::binary);out<<"P6\n"<<W<<" "<<H<<"\n255\n";out.write((char*)c.data(),c.size());}
