import cadquery as cq,json,math
from pathlib import Path
P=Path(__file__).resolve().parent
parts=json.load(open(P/'parts.json'));shapes=cq.importers.importStep(str(P/'RO100_QDD8_assembly.step')).solids().vals()
assert len(parts)==len(shapes)
lookup={p['name']:s for p,s in zip(parts,shapes)}
out={'reimport_solids':len(shapes),'all_valid':all(s.isValid() for s in shapes),'principal_interference_mm3':json.load(open(P/'interference.json')),'all_part_interferences_mm3':[],'gear_motion_samples':[]}
# Complete pair check, broadphase first. Exact intersections retained above numerical threshold.
for i,(p,x) in enumerate(zip(parts,shapes)):
 bx=x.BoundingBox()
 for q,y in zip(parts[i+1:],shapes[i+1:]):
  by=y.BoundingBox()
  if any(getattr(bx,k+'max')<=getattr(by,k+'min')+1e-5 or getattr(by,k+'max')<=getattr(bx,k+'min')+1e-5 for k in 'xyz'):continue
  vv=x.intersect(y).Volume()
  if vv>1e-3:out['all_part_interferences_mm3'].append([p['name'],q['name'],round(vv,6)])
# Motion sampled across one sun tooth pitch; carrier and planet obey Willis relation.
sun=lookup['05_15T_sun_integral_shaft'];ring=lookup['01_fixed_105T_ring'];planet0=lookup['08_planet_1_45T'].translate((-19.5,0,0))
for angle in [0,6,12,18,24]:
 su=sun.rotate((0,0,0),(0,0,1),angle)
 maxvol=0
 for j in range(3):
  theta=math.radians(120*j+angle/8);pl=planet0.rotate((0,0,0),(0,0,1),-angle/6).translate((19.5*math.cos(theta),19.5*math.sin(theta),0))
  maxvol=max(maxvol,su.intersect(pl).Volume(),ring.intersect(pl).Volume())
 out['gear_motion_samples'].append({'sun_deg':angle,'carrier_deg':angle/8,'max_intersection_mm3':maxvol})
json.dump(out,open(P/'validation.json','w'),indent=2);print(json.dumps(out,indent=2),flush=True)
