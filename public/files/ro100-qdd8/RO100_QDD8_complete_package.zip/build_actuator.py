"""RO100 QDD-8 preliminary mechanical design. Units mm. CadQuery 2.x.
Gear flanks are sampled involutes fitted with splines; root transitions are
simplified, NOT production hob-generated trochoids. See accompanying report.
"""
import cadquery as cq, math, json, os
from pathlib import Path
OUT=Path(__file__).resolve().parent
m=.65; alpha=math.radians(25); ns,np_,nr=15,45,105; b=20; a=19.5
parts=[]
COL={'steel':(.53,.59,.65),'al':(.72,.76,.8),'gear':(.83,.65,.28),'rotor':(.27,.31,.37),'stator':(.73,.36,.19),'bearing':(.36,.43,.49),'bolt':(.18,.22,.26)}
def cyl(r,z,h,x=0,y=0):return cq.Workplane('XY').circle(r).extrude(h).translate((x,y,z))
def ann(ro,ri,z,h):return cq.Workplane('XY').circle(ro).circle(ri).extrude(h).translate((0,0,z))
def holes(s,n,r,d,z,h,phase=0):
 for i in range(n):
  t=math.radians(phase+360*i/n); s=s.cut(cyl(d/2,z,h,r*math.cos(t),r*math.sin(t)))
 return s

def add(name,s,mat='steel',note='',density=None):
 sh=s.val() if isinstance(s,cq.Workplane) else s
 assert sh.isValid(),name
 assert len(sh.Solids())==1,(name,len(sh.Solids()))
 density=density or {'al':2.70e-6,'steel':7.85e-6,'gear':7.85e-6,'rotor':7.85e-6,'stator':7.0e-6,'bearing':7.85e-6,'bolt':7.85e-6}[mat]
 parts.append(dict(name=name,shape=sh,mat=mat,note=note,mass=sh.Volume()*density))
 return s

def inv(r,rb):
 q=math.sqrt(max(0,(r/rb)**2-1));return q-math.atan(q)
def polar(r,t):return (r*math.cos(t),r*math.sin(t))
def profile(z,internal=False):
 rp=m*z/2; rb=rp*math.cos(alpha); pitch=2*math.pi/z
 # 0.02 mm tooth thinning on each member: nominal mesh backlash 0.04 mm.
 half=math.pi/(2*z)+(.01/rp if internal else -.01/rp)
 low=rp-m if internal else rp-1.25*m
 high=rp+1.25*m if internal else rp+m
 start=max(low,rb)
 def hw(r):return half-(inv(r,rb)-inv(rp,rb))
 w=cq.Workplane('XY').moveTo(*polar(low,-hw(start)))
 for j in range(z):
  c=j*pitch; h0=hw(start); ht=hw(high)
  if start>low+1e-8:w=w.lineTo(*polar(start,c-h0))
  pts=[polar(start+(high-start)*k/12,c-hw(start+(high-start)*k/12)) for k in range(1,13)]
  w=w.spline(pts,includeCurrent=True)
  w=w.threePointArc(polar(high,c),polar(high,c+ht))
  pts=[polar(high-(high-start)*k/12,c+hw(high-(high-start)*k/12)) for k in range(1,13)]
  w=w.spline(pts,includeCurrent=True)
  if start>low+1e-8:w=w.lineTo(*polar(low,c+h0))
  w=w.threePointArc(polar(low,c+pitch/2),polar(low,c+pitch-h0))
 return w.close()

# Stationary steel ring / stator support, with integral front torque flange.
void=profile(nr,True).extrude(20).translate((0,0,4))
ring=cyl(37,0,28).cut(void).cut(cyl(33.475,0,4)).cut(cyl(33.475,24,4))
for j in range(6):
 key=cq.Workplane('XY').box(1,4,28,centered=(True,True,False)).translate((37.3,0,0)).rotate((0,0,0),(0,0,1),30+60*j)
 ring=ring.union(key)
add('01_fixed_105T_ring',ring,'gear','18CrNiMo7-6 core>=690MPa; OD74 plus six 0.8mm radial drive keys')
adapter=ann(38.95,37.02,-1.5,29.5).union(ann(45,33.475,28,5))
for j in range(6):
 slot=cq.Workplane('XY').box(1.08,4.08,29.5,centered=(True,True,False)).translate((37.30,0,-1.5)).rotate((0,0,0),(0,0,1),30+60*j)
 adapter=adapter.cut(slot)
adapter=adapter.cut(ann(38.1,37.02,-.9,.9));adapter=holes(adapter,8,41,4.5,28,5,22.5)
add('01B_aluminium_stator_heat_sleeve',adapter,'al','6061-T6; ID74.04 OD77.90; six keyed ring slots; front flange; snap ring groove')
snap=ann(38,33.475,-.8,.7).cut(cq.Workplane('XY').box(10,5,2).translate((36,0,-.5)))
add('01C_ring_axial_snap_retainer',snap,'steel','Split spring-steel retaining ring concept; axial gap0.1mm')
for j in range(8):
 t=math.radians(22.5+45*j)
 add(f'01D_ring_flange_M3_insert_{j+1}',ann(2.25,1.25,28,5).translate((41*math.cos(t),41*math.sin(t),0)),'steel','M3 steel insert envelope, bonded/keyed outer anchorage specification required')
# Motor parts are verified dimension envelopes, not a claimed vendor solid.
stator=ann(50,39,4,20).union(ann(49,40,.5,3.5)).union(ann(49,40,24,4))
add('02_RO100_stator_ENVELOPE',stator,'stator','OEM ID78 OD100 stack20; end-turn envelopes; assigned OEM mass335g',.335/stator.val().Volume())
rotor=ann(54.15,50.8,0,28)
add('03_RO100_rotor_ENVELOPE',rotor,'rotor','OEM OD108.3 ID101.6 length28; assigned OEM rotor mass190g',.190/rotor.val().Volume())
# Rotor support bell surrounds the actual outer rotor, with 25um radial adhesive gap.
bell=ann(56,4.1,-8,4).union(ann(56,54.175,-4,32));bell=holes(bell,6,12,4.5,-8,3.5)
add('04_rotor_bell',bell,'al','6061-T6; M3 tapped/insert pilot holes; annular adhesive bond to rotor')
# One-piece steel sun and input shaft; flange transfers motor torque into the shaft.
sun=profile(ns).extrude(20).translate((0,0,4)).union(cyl(4,-25,57).union(cyl(6.1,-14,1)).union(cyl(6.1,24,1))).union(cyl(16,-10,2))
sun=holes(sun,6,12,3.3,-10,2)
add('05_15T_sun_integral_shaft',sun,'gear','42CrMo4 QT certified core >=900MPa; induction-hardened flanks; 8mm journals; integral flange')
# Rear carrier includes three torque posts; front carrier forms the output hub.
rear=ann(32.75,6,0,3.5);rear=holes(rear,3,a,8,0,3.5)
for i in range(3):
 t=math.radians(60+120*i);x,y=23*math.cos(t),23*math.sin(t)
 rear=rear.union(cyl(5,3.5,23,x,y)).cut(cyl(1.65,3.5,23,x,y))
add('06_rear_carrier_with_posts',rear,'steel','4140 QT minimum yield900MPa; three integral 10mm torque posts; M4 tap pilots')
front=ann(32.75,11,24.5,4).union(ann(30,11,28.5,3.5)).union(ann(30,8,32,10)).union(ann(31.75,8,32,2))
front=holes(front,3,a,8,24.5,4)
front=holes(front,3,23,10,24.5,2,60);front=holes(front,3,23,4.4,26.5,15.5,60);front=holes(front,3,23,7,38,4,60)
front=holes(front,6,24,4.2,33,9,30);front=holes(front,6,24,7,34,8,30)
add('07_front_carrier_output_hub',front,'al','7075-T6 procurement yield>=400MPa; 60mm crossed-roller seat; tapped M5 flange pattern',2.81e-6)
# Three planets and individually named commercial bearing envelopes / pins / washers.
planet=profile(np_).extrude(20).cut(cyl(7.5,0,20)).translate((0,0,4))
for i in range(3):
 t=math.radians(120*i);x,y=a*math.cos(t),a*math.sin(t)
 add(f'08_planet_{i+1}_45T',planet.translate((x,y,0)),'gear','OD30.55; bore15 H7; m0.65 25deg')
 add(f'09_NK8_16_planet_bearing_{i+1}',ann(7.5,4,6,16).translate((x,y,0)),'bearing','8x15x16 purchased bearing envelope; C5.01kN C0 5.85kN')
 pin=cyl(4,0,28.5,x,y).union(cyl(5,-1.5,1.5,x,y))
 add(f'10_hardened_planet_pin_{i+1}',pin,'steel','8mm raceway 58-64HRC; press retention in rear carrier')
 for j,z in enumerate([3.5,24]):add(f'11_thrust_washer_{i+1}_{j+1}',ann(7.4,4.05,z,.5).translate((x,y,0)),'steel','0.5mm hardened thrust washer')
 for j,z in enumerate([4,22]):add(f'12_needle_spacer_{i+1}_{j+1}',ann(6,4.05,z,2).translate((x,y,0)),'steel','Axial spacer; clears rotating planet bore')
# Input radial bearings, envelopes separated into races to show motion interfaces.
for label,z in [('rear',-21),('front',25)]:
 add(f'13_608_{label}_inner',ann(6.1,4,z,7),'bearing','608 envelope inner race')
 add(f'13_608_{label}_outer',ann(11,9.1,z,7),'bearing','608 envelope outer race; C3.45kN C0 1.37kN')
 # Nonstructural ball / cage envelope intentionally omitted from mass estimate.
# Output crossed roller ring, simplified separate inner/outer races.
add('14_RA6008_inner_ENVELOPE',ann(33.15,30,34,8),'bearing','THK RA6008 60x76x8; internal geometry simplified')
add('14_RA6008_outer_ENVELOPE',ann(38,34.15,34,8),'bearing','THK RA6008; C5.68kN C0 8.68kN; dp67mm')
# Front housing: pocket for ring flange, bearing shoulder and outer-ring seat.
cover=ann(66,45,28.5,4.5).union(ann(66,35.25,33,1)).union(ann(66,38,34,8))
cover=holes(cover,8,41,3.3,33,9,22.5);cover=holes(cover,8,41,5.6,39,3,22.5);cover=holes(cover,8,60.5,4.4,28,14)
cover=holes(cover,8,41,3.3,36,6,0) # outer retainer M4 tap pilots distinct phase
# radial cable egress, diameter6, clears rotating rotor by exiting axially at front
cover=cover.cut(cyl(3,28,14,49,0))
add('15_front_housing_heat_spreader',cover,'al','6061-T6; stepped output bearing seat; eight housing tie holes; cable port')
outerret=ann(48,35.25,42,4);outerret=holes(outerret,8,41,4.4,42,4)
add('16_output_bearing_outer_retainer',outerret,'al','Clamp outer race only, shoulder diameter70.5')
flange=ann(31.75,8,42,8);flange=holes(flange,6,24,5.5,42,8,30);flange=holes(flange,6,24,9,45,5,30);flange=holes(flange,6,20,7,42,8,0)
add('17_output_leg_flange',flange,'al','7075-T6; 6xM5 PCD40 robot interface; 6xM5 PCD48 hub attachment',2.81e-6)
# Stationary protective shell. Six fins, machined integrally.
housing=ann(66,56.5,-10,38.5)
housing=holes(housing,8,60.5,3.3,-10,38.5)
for z in [-7,-1,5,11,17,23]:housing=housing.union(ann(70,66,z,1.5))
add('18_finned_outer_housing',housing,'al','6061-T6; 1mm diametral bell clearance; 6 fins; tie holes are M4 tap pilots')
cap=ann(66,56.5,-25,15).union(ann(56.5,4.2,-25,4)).union(ann(20,4.2,-21,11)).cut(cyl(11,-21,7)).cut(cyl(17,-14,4))
for i in range(8):
 t=math.radians(22.5+45*i);cap=cap.union(cyl(5,-21,11,50*math.cos(t),50*math.sin(t)))
cap=holes(cap,8,60.5,4.4,-25,15);cap=holes(cap,3,15,1.6,-18,4,30)
# mounting holes, eight M5 holes on a separate 100mm PCD
cap=holes(cap,8,50,4.2,-25,15,22.5)
add('19_rear_housing_robot_mount',cap,'al','6061-T6; rear 608 pocket; 8xM5 PCD100 robot mount')
# rear bearing outer retainer at -11: ring connects rear cap at -10
add('20_rear_608_retainer',holes(ann(16.8,8.5,-14,1),3,15,2.2,-14,1,30),'steel','Three M2 retainers; rear bearing shoulder')
# Encoder mechanical keep-outs (physical board/spacer approximations, no functional electronics claim).
add('21_input_encoder_magnet_ENVELOPE',cyl(3,-27,2),'rotor','Encoder magnet bonded to shaft end; requires sensor standoff')
# Fasteners: cosmetic threads suppressed; solids use tap-minor diameter inside engagement.
def bolt(name,d,x,y,z,shaftlen,headh,headd,mat='bolt'):
 s=cyl(d/2,z,shaftlen,x,y).union(cyl(headd/2,z+shaftlen,headh,x,y))
 # hex socket, easy-to-view but not a full ISO4762 manufacturing solid
 cut=cq.Workplane('XY').polygon(6,max(1.5,d*.65)).extrude(headh*.7).translate((x,y,z+shaftlen+headh*.3))
 add(name,s.cut(cut),mat,'Purchased fastener, simplified shank at pilot diameter; see schedule')
for i in range(3):
 t=math.radians(60+120*i);bolt(f'22_carrier_M4_{i+1}',3.2,23*math.cos(t),23*math.sin(t),3.5,34.5,4,7)
for i in range(6):
 t=math.radians(30+60*i);bolt(f'23_output_M5_{i+1}',4.1,24*math.cos(t),24*math.sin(t),34,11,5,8.5)
# Rotor M3 heads face rear: model separately reversed stack.
for i in range(6):
 t=math.radians(60*i);x,y=12*math.cos(t),12*math.sin(t)
 s=cyl(1.2,-10,5.5,x,y).union(cyl(2.75,-13,3,x,y))
 add(f'24_rotor_M3_{i+1}',s,'bolt','M3-12.9; 1.8kN assembly preload; head faces rear')
for i in range(8):
 t=math.radians(45*i);x,y=41*math.cos(t),41*math.sin(t)
 bolt(f'25_retainer_M4_{i+1}',3.2,x,y,36,10,4,7)
 # front shell tie bolts
 t=math.radians(45*i);x,y=60.5*math.cos(t),60.5*math.sin(t)
 bolt(f'26_front_tie_M4_{i+1}',3.2,x,y,20,22,4,7)
 # rear shell bolts reversed, head outside rear cap
 s=cyl(1.6,-25,23,x,y).union(cyl(3.5,-29,4,x,y))
 add(f'27_rear_tie_M4_{i+1}',s,'bolt','M4-10.9 tie bolt, simplified')
 # ring flange mounting screws inserted from rear into front plate
 t=math.radians(22.5+45*i);x,y=41*math.cos(t),41*math.sin(t)
 s=cyl(1.2,28,11,x,y).union(cyl(2.75,39,3,x,y))
 add(f'28_ring_M3_{i+1}',s,'bolt','M3-12.9; head recessed on front face; tapped steel ring flange')
for i in range(3):
 t=math.radians(30+120*i);bolt(f'29_rear_retainer_M2_{i+1}',1.5,15*math.cos(t),15*math.sin(t),-18,5,2,3.5)
for i in range(6):
 t=math.radians(60*i);add(f'30_rotor_M3_insert_{i+1}',ann(2.25,1.25,-8,3.5).translate((12*math.cos(t),12*math.sin(t),0)),'steel','Threaded insert envelope; outer anchorage to be specified')
 t=math.radians(30+60*i);add(f'31_hub_M5_insert_{i+1}',ann(3.5,2.1,34,8).translate((24*math.cos(t),24*math.sin(t),0)),'steel','Steel M5 insert envelope; qualified external engagement required')
 t=math.radians(60*i);add(f'32_leg_M5_insert_{i+1}',ann(3.5,2.1,42,8).translate((20*math.cos(t),20*math.sin(t),0)),'steel','Steel M5 insert envelope; max leg screw penetration7mm')
assembly=cq.Assembly(name='RO100_QDD8_PRELIMINARY_R1')
for p in parts:assembly.add(p['shape'],name=p['name'],color=cq.Color(*COL[p['mat']]))
assembly.save(str(OUT/'RO100_QDD8_assembly.step'))
json.dump([{k:v for k,v in p.items() if k!='shape'} for p in parts],open(OUT/'parts.json','w'),indent=2)
# BRep for local independent reimport and mesh rendering.
compound=cq.Compound.makeCompound([p['shape'] for p in parts]);cq.exporters.export(compound,str(OUT/'assembly.brep'))
print('PARTS',len(parts),'MASS_ENVELOPE_KG',sum(p['mass'] for p in parts),flush=True)
# Mesh at modest tolerance for reproducible preview.
mesh=[]
for p in parts:
 vs,fs=p['shape'].tessellate(.12,.15)
 mesh.append(dict(name=p['name'],color=COL[p['mat']],vertices=[v.toTuple() for v in vs],faces=fs))
json.dump(mesh,open(OUT/'preview_mesh.json','w'))
# Exact intersections of the load-carrying members, excluding purchased bearing interiors.
checks=[]
important=[p for p in parts if not p['name'].startswith(('13_','14_','21_','22_','23_','24_','25_','26_','27_','28_'))]
for i,p in enumerate(important):
 for q in important[i+1:]:
  bp,bq=p['shape'].BoundingBox(),q['shape'].BoundingBox()
  if any(getattr(bp,k+'max')<=getattr(bq,k+'min')+1e-6 or getattr(bq,k+'max')<=getattr(bp,k+'min')+1e-6 for k in 'xyz'):continue
  v=p['shape'].intersect(q['shape']).Volume()
  if v>1e-4:checks.append([p['name'],q['name'],v])
json.dump(checks,open(OUT/'interference.json','w'),indent=2)
print('INTERFERENCES',checks,flush=True)
