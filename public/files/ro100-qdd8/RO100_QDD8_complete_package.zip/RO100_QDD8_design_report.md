RO100 / QDD-8

Multipart mechanical concept and reproducible design calculations

Revision R1 | 29 September 2026 | Dimensions: mm; forces: N; torques: N·m

**Status: preliminary engineering design, not a manufacturing release.** The specified CubeMars RO100 KV55 Lite is retained. The working planetary stage lies inside its Ø78 bore and 28 mm nominal motor envelope. Ratio is exactly 8:1. Joint-support bearings, covers and rotor support extend axially beyond the motor. No replacement motor or external gear stage is used.

Item | R1 result / boundary

Reduction | Fixed ring; sun input; three planets; carrier output

Tooth counts | 15 / 45 / 105; custom module 0.65; 25° pressure angle

Motor-side command ceiling | 6 N·m provisional; 12 N·m OEM peak is NOT an R1 gearbox rating

Calculated output | 30.08 N·m at 4 N·m input; 45.12 N·m at 6 N·m, assuming η = 0.94

Mechanical envelope | Ø140 including fins × 79 axial, including rear bolt heads; approximately 2.86 kg

Files | 119 named STEP solids; Python CAD generator; independent calculations; BOM; reference motor drawing

A completed geometric concept is supplied, with explicit analytical assumptions. Gear-root production geometry, fatigue allowables, OEM envelope agreement, thermal tests and detailed tolerances remain release gates. Finite-element analysis, durability testing and a complete motor-controller PCB were not performed.

1  Requirements, loads and motor interfaces



What is verified, assumed, and still open

Manufacturer inputs [1,2]: 48 V; 4 N·m rated; 12 N·m peak; 2000 rpm rated; 2550 rpm no-load; 525 g; Kt = 0.2 N·m/A; Km = 0.53 N·m/√W; 21 pole pairs. The PDF shows Ø78 +0.06 stator bore, Ø100 stator envelope, Ø101.6 rotor inner diameter, Ø108.3 ±0.07 rotor outer diameter and 28 overall length. Winding, adhesive and current conventions require OEM confirmation.

**Motor CAD discrepancy:** the downloaded CubeMars STEP [3] contains 46 open shells, zero closed solids, and 31.5 mm maximum axial extent. The PDF says 28 mm. R1 uses the PDF dimensions and labels the two motor solids as ENVELOPE parts; it does not silently substitute repaired OEM geometry. Confirm whether the extra 3.5 mm is winding/lead protrusion before machining covers. The unmodified vendor STEP is included in the source package.

Design input | Assumption / purpose

Drive torque | 4 N·m sustained thermal target; 6 N·m short command ceiling; not yet qualified

Gear multipliers | KA = 1.50 overload; Kγ = 1.25 planet sharing; Kv = 1.10 dynamics; Kβ = 1.15 face distribution

Output bearing transient | Fr = 1000; Fa = 500; transverse moment M = 50 N·m, simultaneous

Output moving-life example | Fr = 300; Fa = 150; M = 15 N·m; 100 rpm equivalent; load multiplier 1.5

Input bearing allowance | 300 N per bearing; includes preliminary magnetic/unbalance allowance

Moving thermal/life spectrum | 6 N·m for 10%; 4 for 30%; 1 for 60%; motor 800 rpm; speed-independent standstill heating also checked

Environment | 40°C ambient; winding target ≤100°C; bearing ≤80°C; thresholds are provisional

Robot-level check; not a promised quadruped rating

Tjoint = (Mrobot g kd / nsupport) leff
Example: 60 × 9.81 × 1.5 / 2 × 0.10 = 44.15 N·m

This is a modest-dynamics example with a short effective moment arm, not a gait simulation. Twelve R1 actuators weigh roughly 34.27 kg before controllers and cables; the robot mass budget must include this. Hip and knee torque histories, impact energy, gait frequency and actual moment arms were not supplied. Backdriving impacts must also obey the gearbox load envelope; a motor current limit cannot cap an externally imposed impact.

Axial arrangement and assembly datums

Component | z range / interface

Motor envelope / gear faces | Motor 0…28; gear teeth 4…24; planets’ needle bearings 6…22

Carriers / retention | Rear 0…3.5; front 24.5…28.5; rear pin heads −1.5…0

Stator support / ring | Al sleeve Ø77.90 in Ø78 bore; steel ring Ø74 plus keys; flange 28…33

Input bearings | 608 rear −21…−14; 608 front 25…32; sun Ø8 journals

Output joint bearing / flange | RA6008 34…42; Ø60 hub; output flange 42…50

Stationary covers / clearance | Rear cap −25…−10; front cover starts 28.5; ≥0.5 axial rotor-cover gap

2  Gear geometry and exact reduction



Kinematics from the stationary carrier reference frame

(ωs − ωc)/(ωr − ωc) = −Zr/Zs
ωr = 0  ⇒  ωs/ωc = 1 + Zr/Zs = 1 + 105/15 = 8
ωp = ωc − (Zs/Zp)(ωs − ωc) = −ωs/6

Subtracting carrier speed makes the moving-axis train a conventional external sun–planet mesh followed by an internal planet–ring mesh. No slip at the pitch circles gives the first equation. Energy balance gives Tout = η i Tin; ideal ring reaction is (i − 1)Tin. At Tin = 6, ideal carrier torque is 48 and ring reaction 42 N·m. Losses reduce delivered torque; 94% is a design assumption to measure, not a catalogue guarantee.

Check | Calculation | Result

Concentricity | Zr = Zs + 2Zp | 105 = 15 + 90

Equal planet assembly | (Zs + Zr)/3 | 40, integer

Pitch diameters | mZ | 9.75 / 29.25 / 68.25

Centre distance | m(Zs + Zp)/2 | 19.50

Planet non-overlap | 2a sin(60°) − m(Zp+2) | 3.22 clearance

Ring tip / root diameters | m(Zr−2) / m(Zr+2.5) | 66.95 / 69.875

Ring rim | (74 − 69.875)/2 | 2.06; rim/tooth depth = 1.41

Undercut screen | Zmin = 2/sin²25° | 11.20 < 15

Contact ratios | External / internal | 1.44 / 1.63

Why these dimensions

An 8:1 simple planetary fixes Zr = 7Zs and Zp = 3Zs. Three planets permit load sharing while four standard equally spaced planets of this proportion interfere. Fifteen sun teeth give a compact integer solution. A 25° involute avoids the zero-shift undercut that a 15-tooth, 20° full-depth pinion would encounter. The non-stock 0.65 module reserves steel rim and a thermally conductive sleeve inside Ø78; it requires custom tooling or form cutting. The 20 mm face uses the central motor stack and leaves room for carriers and axial clearances.

rb = r cos α; inv(α) = tan α − α; r = rb √(1+t²)
External flank half-width θ(r) = π/(2Z) − Δs/(2rp) + inv(α) − inv(αr)
εext = [√(ras²−rbs²)+√(rap²−rbp²)−a sin α]/(πm cos α)
εint = [√(rap²−rbp²)−√(rar²−rbr²)+a sin α]/(πm cos α)

The CAD uses spline-fitted involute flanks and circular tip/root arcs. Each member is thinned 0.02 mm at its pitch circle, giving nominal mesh backlash about 0.04 mm. Root connections below the base circle are simplified; they are not a hob-generated trochoid. The production root fillet, profile error and backlash stack require a gear supplier’s signed drawing and rating. A single favourable assembled position is not a motion proof.

3  Tooth strength: Lewis and Hertz derivations



Load sharing and bending from the beam equation

Ft,nom = 2Tin/(Nplanet ds); Ft,d = KA Kγ Kv Kβ Ft,nom
K = 1.50 × 1.25 × 1.10 × 1.15 = 2.371875
σ = Mc/I; M = Fth; c=t/2; I=bt³/12
σ = 6Fth/(bt²) = Ft/(bmY); Y = t²/(6hm)
σscreen = Kroot [Ft,d/(bmY) + Fn/(bt)]; Fn=Ft,d/cos α

To avoid assigning a favourable handbook factor to custom geometry, the calculation samples radial sections of the actual simplified sun and planet profiles and takes the minimum Y. Sun: Y = 0.20245, t = 1.0746, h = 1.4625. Planet: Y = 0.38200. The added direct normal stress is conservative. Kroot = 1.35 is an assumed finite-fillet allowance, not a solution for the CAD’s sharp root junction. It must be replaced by a manufacturable fillet and stress concentration from FEA or a gear standard. Load factors are engineering allowances, not mechanical theorems.

Tin | Tout @94% | Sun σ, MPa | 900/σ | Pitch p0, MPa

4 | 30.08 | 377.72 | 2.38 | 922.32

5 | 37.60 | 472.16 | 1.91 | 1031.19

6 | 45.12 | 566.59 | 1.59 | 1129.61

8 | 60.16 | 755.45 | 1.19 | 1304.36

12 | 90.24 | 1133.17 | 0.79 | 1597.51

**Decision:** specify the sun as 42CrMo4, quenched and tempered to a certified core yield of at least 900 MPa, with separately qualified induction-hardened flanks. The grade name alone does not guarantee that strength after heat treatment [8]. At 6 N·m the screen is 566.6 MPa and the nominal static margin is 1.59. Including a separate 1.5 shaft-torsion concentration and the 1.5 overload raises the sun’s combined bending/torsion screen to about 609 MPa, reducing the conditional margin to about 1.48. This must be resolved in the production-root FEA; 6 N·m remains provisional. At 12 N·m it fails this screen. Planets use carburized 18CrNiMo7-6 with certified core ≥690 MPa [7]; their 6 N·m root screen is 358.6 MPa, margin 1.92. Ring material matches the planets; its thicker internal tooth is not the governing external-tooth screen.

Contact pressure from elastic line contact

1/E* = (1−ν1²)/E1 + (1−ν2²)/E2; E*=115385 MPa
ρs = rs sin α; ρp = rp sin α
1/R*ext = 1/ρs + 1/ρp; 1/R*int = 1/ρp − 1/ρr
aH = √[4FnR*/(πbE*)]; p0 = 2Fn/(πbaH) = √[FnE*/(πbR*)]

At 6 N·m, the sun–planet pitch-point pressure is 1129.6 MPa; planet–ring is 427.0 MPa. This explains hardened steel flanks rather than aluminium teeth. These are pitch-point screens, not maximum pressure over the entire path of contact, and hardness is not a contact-fatigue allowable. Case depth, residual stress, reversal, lubrication, edge loading, scuffing and pitting require supplier data and ISO 6336/AGMA-style rating. No fatigue safety factor or certified gear life is claimed.

Nominal root yield margin is therefore conditional, not proof of unlimited operation. The stationary ring’s thin-rim ratio is 1.41; a ring flexibility/load-distribution model remains necessary despite the surrounding sleeve. Metal proof torque testing is required after dimensional inspection.

4  Pins, carrier, shaft and bearing selection



Planet pins and carrier load path

Fpin ≈ 2Ft,d = 1946 N at Tin=6
Double shear: τ = Fpin/(2πd²/4)
Supported beam: Mmax=Fpin L/4; σb=32Mmax/(πd³)
δ = Fpin L³/(48EI); d=8, L=25, E=210000 MPa

Results: pin von Mises screen 244.3 MPa and midspan deflection 0.0150 mm. Hardened 100Cr6 pins require a ground 58–64 HRC raceway, Ra ≤0.2 μm and certified core yield ≥1000 MPa: static screen margin ≥4.09. The span approximation concentrates the load, conservatively relative to the distributed needle load. Pin tilt still influences gear face loading.

Each front/rear pin seat reacts about 973 N. Projected bearing stress is 973/(8×4) = 30.4 MPa at the front and 34.8 MPa at the 3.5 mm rear plate. A conservative rear-plate strip, length 12, width 15 and thickness 3.5, gives 381 MPa. The rear carrier therefore uses 42CrMo4 QT ≥900 MPa, not aluminium. The front hub uses 7075-T6 with procurement yield ≥400 MPa; its pin bores terminate into the thick hub.

Three Ø10 integral posts at radius 23 carry carrier torque by bearing in fitted pockets. Taking the full 48×1.5 = 72 N·m through all posts gives 1043 N/post. A 23 mm cantilever with Ø3.3 tap pilot has Z = π(D⁴−d⁴)/(32D) ≈97 mm³; nominal post bending ≈247 MPa. A 1.5 root factor gives ≈371 MPa, margin 2.43 against 900 MPa. Rear-plate/post fillets and combined pin loads require FEA. Three M4 screws clamp the fitted posts; bolt friction is not the sole torque path.

Input shaft and sleeve keys

Solid shaft: τmax = 16T/(πd³)
At T=6 N·m, d=8: τ=59.7 MPa; √3τ=103.4 MPa
With torsional Kt=1.5: equivalent≈155 MPa &lt;900 MPa

The sun’s root diameter is 8.125 mm, so the Ø8 journals do not fill in the root clearance. Shaft bending from an assumed residual 300 N over 46 mm gives ≈69 MPa before concentration. Using 1.5 on bending and torsion gives combined stress about 187 MPa, margin about 4.8. Actual unbalanced magnetic pull requires OEM air-gap/runout data.

Six steel ring keys enter aluminium slots. Assume only three share torque: with 42×1.5 N·m, r=37 and conservative effective key height 0.8 over 20 length, each key sees 568 N; bearing pressure 35.5 MPa. Aluminium yield ≥240 MPa gives margin 6.8. The keys preserve torque transmission when thermal expansion opens the steel/aluminium fit; no adhesive friction is required for ring reaction torque.

Bearing capacities and empirical life

Bearing | C / C0 | Static calculation | Moving-life screen

3× SKF NK8/16 TN [4] | 5.01 / 5.85 kN | 5850/1946 = 3.01 | 36009.84 h

2× SKF 608 [5] | 3.45 / 1.37 kN | 1370/300 = 4.57 | 12673.96 h

THK RA6008 [6] | 5.68 / 8.68 kN | P0=2713 N; C0/P0=3.20 | 16700.51 h

P0,out = Fr + 2M/dp + 0.44Fa; dp=67 mm
Pc,out = Fr + 2M/dp + 0.45Fa = 815 N for stated moving case
Peq = [Σ fj Pj^p]^(1/p); L10h = (C/Peq)^p 10^6/(60n)

Needles use p=10/3; ball bearings use p=3. For the output ring, a conservative cubic screen with 1.5Pc is shown; confirm the selected catalogue rating basis and THK life method before release. Oscillation, fretting, false brinelling, contamination and preload can dominate quadruped life. L10 is a statistical empirical model, not a deterministic life proof. Bearing races in STEP are simplified envelopes without rolling elements or seals.

5  Bolts, inserts, bonds and housing



Bolt-group derivation and number selection

Q = T/(nr); Pext,max = Fa/n + 2M/(nr)
The moment term follows Σ yi² = nr²/2 for a circular bolt group.
Tslip = n μ Fp,min r; nmin = ceil(Tdesign/(μ Fp,min r))
Fp,min=0.75Fp,nom; μmin=0.12 assumed on clean dry faying faces
σVM = √{[(Fp + CjPext)/As]² + 3(Q/As)²}; Cj=0.25 assumed

The slip calculation sizes torque joints first; the combined-stress check is a conservative fallback. Preload variation of ±25% must be tightened by calibrated assembly trials. Friction and joint stiffness must be measured. Use steel inserts in highly preloaded aluminium joints; smooth insert shapes in STEP reserve space but do not specify their external locking mechanism [9].

Joint | Count / nominal preload | Demand incl.1.5 | Minimum slip capacity

Output hub flange, r24 | 6×M5-12.9 / 8.5 kN | 72 N·m | 110.16 N·m; nmin=4

Leg interface, r20 | 6×M5-12.9 / 8.5 kN | 72 N·m | 91.80 N·m; nmin=5

Ring sleeve flange, r41 | 8×M3-12.9 / 2.5 kN | 63 N·m | 73.80 N·m; nmin=7

Housing ends, r60.5 | 8×M4-10.9 / 4.0 kN per end | 72 N·m | 174.24 N·m; nmin=4

Rotor bell, r12 | 6×M3-12.9 / 1.8 kN | 9 N·m | 11.66 N·m; nmin=5

Carrier posts | 3×M4-10.9 / 3.0 kN | Torque via fitted posts | Clamp and axial retention

Output outer retainer | 8×M4-10.9 / 1.5 kN | ≈2.0 kN axial/moment equivalent | 9 kN total minimum clamp

Rear 608 retainer | 3×M2-10.9 / 0.4 kN | 100 N axial allowance | 0.9 kN minimum clamp

Six or eight bolts maintain circumferential symmetry, distribute local flange bending and permit the required slip capacity. The theoretical minimum alone is not enough to protect a thin bearing ring from distortion. Use machined shoulder stops/shims so retaining-bolt preload clamps the races without imposing uncontrolled rolling-element preload.

Thread stripping screen: Ashear ≈ 0.5π dp Le; τthread = Fp/Ashear
Outer insert anchorage screen uses its outer diameter instead of dp.
Installation estimate: Mtorque ≈ K Fp d; K≈0.20 only as a starting estimate

Examples: the Ø7×8 M5 insert envelope has approximate outer shear area 88 mm²; at 8.5 kN, τ≈97 MPa, versus 400/√3≈231 MPa for specified 7075. The Ø4.5×5 M3 flange insert has 35 mm², τ≈71 MPa, versus 240/√3≈139 MPa for 6061. The Ø4.5×3.5 rotor insert sees ≈73 MPa at 1.8 kN. Real insert pullout and edge distance still require the selected insert maker’s rating. Cap leg screws at 7 mm penetration to avoid internal fasteners.

Bonds and thermal expansion

Tbond = τ (2πrL) r
At motor peak12: τstator=0.063 MPa; τrotor=0.027 MPa
Rotor radial centrifugal pressure p≈mrotor ω²/(2πL)=0.090 MPa at2550rpm

Stator bond: nominal radial gap 0.05 mm; rotor-to-bell bond: 0.025 mm nominal, both before tolerances. Require qualified adhesive hot-strength, peel/fatigue, thermal conductivity, gap range and expansion compliance. Differential aluminium/steel growth at Ø78 over 60 K is about 0.051 mm diametral, comparable to the bond gap. For the keyed ring this is tolerated by clearance; for motor bonds it needs compliant material and a thermal-mechanical test. No adhesive product is approved solely by these low average stresses.

Housing screens: rear mounting web 4 mm, local strip width15, span10.5 and 1.5×312.5 N gives ≈123 MPa; 6061 minimum yield240 gives margin≈1.95. Front housing strip width20, thickness8, span22.5 and load1408 N gives≈148 MPa, margin≈1.62. These local beam screens justify the starting thicknesses; complete flange/bolt/press-fit FEA is still required.

6  Heat removal, controls and efficiency



Thermal model and why the sleeve is aluminium

Pcu = (T/Km)²; Trms = √(Σ fj Tj²)
At 4 / 6 / 12 N·m: Pcu = 57.0 / 128.2 / 512.6 W
For the stated spectrum: Trms=3.00 N·m; Pcu=32.04 W
Pgear=(1−η)|Tmωm|; include 15 W provisional iron/bearing allowance
Ptotal≈59.1 W; required Rwinding−ambient ≤(100−40)/Ptotal

Km gives a consistent loss estimate without confusing DC-bus current with RMS phase current or applying the 143 mΩ line-to-line resistance incorrectly. At stall gearbox power loss tends to zero but motor copper heating remains. Peak torque duration cannot be derived without winding thermal capacitance and measured thermal impedances.

Thermal element | Model / result

Aluminium stator sleeve | R=L/(kA), k=170 W/mK, L14 mm, key slots removed: 0.19 K/W

Additional internal terms | 0.30 winding/core + 0.011 bond + 0.10 flange/contact K/W; assumed

Total internal | Rinternal = 0.60 K/W

Six annular fins | OD140, root132, thickness1.5; effective total area 0.0548 m²; assumed fin efficiency0.90

Natural convection, h8 | Rair = 2.28 K/W; predicted rise 170.09 K: FAIL

Forced air, h60 | Rair = 0.30 K/W; predicted rise 53.33 K: conditional pass

Required system thermal resistance | 1.02 K/W for stated moving spectrum

The steel toothed ring is separate from the aluminium heat sleeve. The sleeve takes heat directly from the stator bore to the stationary front flange, while six mechanical keys carry ring torque. This avoids relying on the approximately 0.50 K/W axial conduction of an all-steel sleeve. Use 6061 for housing and fins because heat transfer and machinability dominate; use stronger 7075 only in the output carrier/flange where local stress dominates.

**Cooling requirement:** supply measured airflow giving at least the assumed h, or conduct the front mounting face into a cooled chassis. No fan, liquid loop or remote heatsink is included in the STEP. The calculation is a sizing target, not verified cooling performance. At 4 N·m and 2000 rpm, gearbox loss alone is about 50 W; combined heat exceeds this duty example. Thus 250 rpm output is a kinematic speed, not a simultaneous continuous torque-speed guarantee.

Heat pipes and other options

A heat pipe lowers transport resistance; it does not remove the need for a condenser and sufficient ambient heat-rejection area. The short, stationary aluminium path is already about 0.19 K/W. R1 therefore uses the simpler conductive sleeve and fins. Add a qualified heat pipe only if a remote cooled frame is available and a measured resistance budget demonstrates benefit; wick orientation, minimum bend radius and capillary limit must be checked.

Control and backdrivability

Use external 48 V sensored FOC with an absolute rotor encoder; absence of Hall sensors is not a justification for sensorless zero-speed stance control. A Ø6 encoder magnet envelope is shown; the encoder PCB, bracket and sealing are not designed. At 6 N·m, Kt suggests 30 A in the OEM current convention; calibrate actual phase-current scaling. Add winding and case temperature sensing, overcurrent, overspeed, undervoltage and regeneration handling. An independent output encoder is recommended for backlash compensation and fault detection.

Jreflected,motor = i² Jmotor = 64 × 5290×10⁻⁷ = 0.033856 kg·m²

Rotor bell, sun and planet inertias add to this value. An 8:1 ratio alone does not establish low reflected inertia or low breakaway torque. Measure backdrive friction and impact response; the relatively large motor inertia limits leg acceleration. The provisional efficiency is not a stiffness or backdrivability measurement.

7  Manufacturing intent, assembly and verification



Materials and finish specification

Part family | Procurement / finish intent | Reason and qualification

Sun and input shaft | 42CrMo4; core yield≥900 MPa; qualified induction hardening, final flank/journal grinding | Root screen governs; certify properties after final process

Planets / ring | 18CrNiMo7-6; core≥690 MPa; 58–62 HRC case; candidate effective case0.25–0.40 mm | Wear/contact strength; case depth and distortion need supplier approval

Rear carrier / pins | Carrier QT≥900 MPa; 100Cr6 pins 58–64 HRC, core≥1000 MPa | Post bending / needle race contact

Front carrier / output flange | 7075-T6, certified yield≥400 MPa; protect exposed surfaces | Local bearing, bolt and web strength

Housing / motor sleeve / bell | 6061-T6, certified yield≥240 MPa, k≈170 W/mK | Thermal path and modest screened stresses

Thrust washers / retaining ring | Hardened steel washers; spring-steel axial retainer | Planet axial positioning; no spur-gear axial thrust

Material values are minimum procurement requirements or explicitly assumed thermal properties. A temper/grade label is not a substitute for batch certification, and thermal properties and strength vary with temperature. Mask bearing seats, bonds and conductive contact faces from insulating anodize. Prevent galvanic corrosion at steel/aluminium interfaces without fouling gear lubricant.

Tolerance and lubrication targets, not encoded as manufacturing tolerances

Use a common datum axis from the Ø60 output-bearing seat and front housing register. Preliminary targets: pin centre true position ≤0.015 mm; gear-face parallelism ≤0.01 mm; input-bearing coaxiality ≤0.02 mm; rotor/stator total runout ≤0.05 mm. Recompute sharing and air gap from the full tolerance stack. Set planet bores and pin fits from SKF rotating-outer-ring recommendations; H7 alone is only a starting CAD annotation. THK shoulder limits are shaft shoulder ≤Ø63.5 and housing shoulder ≥Ø70.5; both are represented. Race retention must never bridge the moving and fixed rings.

Specify low-drag EP grease compatible with needle bearings, seals and hardened gears after a supplier review. Verify grease quantity, mesh churning, relubrication interval and temperature. The CAD does not include a sealed lubrication chamber, labyrinth/lip seals or an IP rating; these need detailed design before environmental operation. Finite backlash is intentional; the nominal 0.04 mm per mesh is not a guaranteed output angular backlash.

Assembly sequence

1. Inspect and finish gears, heat treatment and journals. Assemble the keyed steel ring into the aluminium sleeve from the rear; fit the split axial retainer. 2. Pre-fit needle bearings into each planet, then position planets inside the ring at z4…24 using a phasing fixture. The assembled planet set cannot pass the ring end lip as a unit. Insert the rear carrier and pins axially, add spacers/washers, and pass the sun through the rear carrier bore. Close the front carrier onto the fitted posts and torque its three M4 screws. 3. Install and retain both input bearings and the output cross-roller ring without transmitting installation force through rolling contacts. 4. Bond the stator to the stationary sleeve and the OEM rotor into the bell with controlled coaxial fixtures. 5. Attach the bell to the sun flange, install front/rear covers and bearing retainers, then the output flange. 6. Add the qualified inserts, sensors, lubrication enclosure and wiring; measure runout, backlash and no-load current before energising at reduced limits.

Validation performed and limits

STEP re-import found 119 valid solids. Reference-pose checks found no positive-volume interference after correcting eight housing holes. Five gear-motion samples across one sun-tooth pitch also found none. The validation file records these geometric checks. Threads, commercial bearings, OEM motor internals and inserts remain simplified; these checks do not establish strength, life or manufacturability.

**Release gates:** reconcile CubeMars 28/31.5 mm envelopes and lead exits; replace simplified tooth roots with production fillets; complete mesh/rim/shaft/housing FEA and fatigue rating for an actual gait spectrum; select bearing fits/clearance/retention and certified inserts; close the thermal/current limit through instrumented stall and motion tests; add sealing and electrical integration; perform static proof, endurance and backdrive tests.

8  Parts, references and reproducibility



Assembly bill of materials (grouped; exact part list in parts.json)

Part code | Qty | Mass, kg | Description

01 | 1 | 0.153 | 18CrNiMo7-6 core>=690MPa; OD74 plus six 0.8mm radial drive keys

01B | 1 | 0.071 | 6061-T6; ID74.04 OD77.90; six keyed ring slots; front flange; snap ring groo

01C | 1 | 0.005 | Split spring-steel retaining ring concept; axial gap0.1mm

01D | 8 | 0.003 | M3 steel insert envelope, bonded/keyed outer anchorage specification require

02 | 1 | 0.335 | OEM ID78 OD100 stack20; end-turn envelopes; assigned OEM mass335g

03 | 1 | 0.190 | OEM OD108.3 ID101.6 length28; assigned OEM rotor mass190g

04 | 1 | 0.160 | 6061-T6; M3 tapped/insert pilot holes; annular adhesive bond to rotor

05 | 1 | 0.038 | 42CrMo4 QT certified core >=900MPa; induction-hardened flanks; 8mm journals;

06 | 1 | 0.123 | 4140 QT minimum yield900MPa; three integral 10mm torque posts; M4 tap pilots

07 | 1 | 0.122 | 7075-T6 procurement yield>=400MPa; 60mm crossed-roller seat; tapped M5 flang

08 | 3 | 0.231 | OD30.55; bore15 H7; m0.65 25deg

09 | 3 | 0.048 | 8x15x16 purchased bearing envelope; C5.01kN C0 5.85kN

10 | 3 | 0.037 | 8mm raceway 58-64HRC; press retention in rear carrier

11 | 6 | 0.003 | 0.5mm hardened thrust washer

12 | 6 | 0.006 | Axial spacer; clears rotating planet bore

13 | 4 | 0.021 | 608 envelope inner race

14 | 2 | 0.094 | THK RA6008 60x76x8; internal geometry simplified

15 | 1 | 0.304 | 6061-T6; stepped output bearing seat; eight housing tie holes; cable port

16 | 1 | 0.035 | Clamp outer race only, shoulder diameter70.5

17 | 1 | 0.055 | 7075-T6; 6xM5 PCD40 robot interface; 6xM5 PCD48 hub attachment

18 | 1 | 0.414 | 6061-T6; 1mm diametral bell clearance; 6 fins; tie holes are M4 tap pilots

19 | 1 | 0.285 | 6061-T6; rear 608 pocket; 8xM5 PCD100 robot mount

20 | 1 | 0.005 | Three M2 retainers; rear bearing shoulder

21 | 1 | 0.000 | Encoder magnet bonded to shaft end; requires sensor standoff

22 | 3 | 0.010 | Purchased fastener, simplified shank at pilot diameter; see schedule

23 | 6 | 0.019 | Purchased fastener, simplified shank at pilot diameter; see schedule

24 | 6 | 0.005 | M3-12.9; 1.8kN assembly preload; head faces rear

25 | 8 | 0.014 | Purchased fastener, simplified shank at pilot diameter; see schedule

26 | 8 | 0.020 | Purchased fastener, simplified shank at pilot diameter; see schedule

27 | 8 | 0.021 | M4-10.9 tie bolt, simplified

28 | 8 | 0.008 | M3-12.9; head recessed on front face; tapped steel ring flange

29 | 3 | 0.001 | Purchased fastener, simplified shank at pilot diameter; see schedule

30 | 6 | 0.002 | Threaded insert envelope; outer anchorage to be specified

31 | 6 | 0.009 | Steel M5 insert envelope; qualified external engagement required

32 | 6 | 0.009 | Steel M5 insert envelope; max leg screw penetration7mm

Mass uses nominal solid volume and assigned densities. Motor mass is assigned from the OEM 335 g stator / 190 g rotor figures. Bearing rolling elements, lubricant, sensors, controller, connectors and seals are incomplete or absent; the total is an approximate mechanical CAD mass, not a weighed actuator.

9  Source register and delivery notes



**[1] CubeMars RO100 KV55 Lite without Hall product specification**

https://www.cubemars.com/product/ro100-kv55-lite-without-hall-frameless-torque-motor.html

**[2] CubeMars RO100 Lite PDF; bore and section drawing; downloaded with source package**

https://img.cubemars.com/products/cubemars-product-parameter/RO100-LITE-KV55.pdf

**[3] CubeMars original RO100-KV55-lite STEP ZIP; corrected relative download path**

https://www.cubemars.com/data/cms/202602/ro100-kv55-lite-frameless-torque-motor-3d-drawing.zip

**[4] SKF rolling-bearing catalogue; NK8/16 TN dimensions and capacities**

https://cdn.skfmediahub.skf.com/api/public/09468794f5d8f85a/pdf_preview_medium/09468794f5d8f85a_pdf_preview_medium.pdf

**[5] SKF same primary catalogue; 608, 8×22×7, C3.45 kN, C0 1.37 kN**

Same catalogue as [4].

**[6] THK RA/RAU dimensional table, page A18-33; RA6008 capacities and shoulder geometry**

https://tech.thk.com/en/products/pdfs/en_a18_032.pdf

**[6a] THK Cross-Roller Ring catalogue, equivalent-load methods; some content requires login**

https://tech.thk.com/en/products/pdf_download.php?file=E_18_CrossRollerRing.pdf

**[7] Ovako 18CrNiMo7-6 material data; core properties depend on condition and section**

https://steelnavigator.ovako.com/steel-grades/18crnimo7-6/

**[8] Ovako 42CrMo4 material data and heat-treatment response**

https://steelnavigator.ovako.com/steel-grades/42crmo4/

**[9] NASA RP-1228, Fastener Design Manual, Richard T. Barrett, 1990**

https://ntrs.nasa.gov/citations/19900009424

**[10] Hydro 6061 alloy data; heat-transfer application and material-selection context**

https://www.hydro.com/Document/Index?id=560718&amp;name=Alloy+6061.pdf

**[11] KHK Internal Gears catalogue; internal-gear/planetary design context**

https://khkgears.net/pdf/2025/internal-gears.pdf

Sources accessed 29 September 2026. Manufacturer values are separated from assumptions throughout this report. The calculations are original analytical screens based on the displayed equations; no claim is made that an external source has certified this actuator.

Reproduce and inspect

python build_actuator.py    # CadQuery required; exports named STEP assembly
python calculations.py      # Standard-library engineering calculations
python render_software.py  # NumPy + Pillow; compile raster.cpp first
python make_report.py      # ReportLab + Pillow

The source package contains the CAD generator, independent calculations and results, exact part list, validation record, report generator and OEM motor references. STEP contains separate assembly components rather than a fused union. It does not carry a native SolidWorks feature history or motion mates. The Python generator supplies editable design parameters; changes require re-running every affected calculation and verification.

**Unresolved requirement:** a fully proven, fabrication-ready actuator cannot honestly be claimed from these inputs and analytical screens. This delivery is a reviewable R1 mechanical concept with explicit calculations and open release items, not a certified quadruped joint.