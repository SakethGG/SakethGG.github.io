# RO100 QDD-8 / R1 mechanical concept

This is a preliminary, reviewable mechanical design, NOT a manufacturing release.
Read RO100_QDD8_design_report.pdf before using the STEP.

- Required motor: CubeMars RO100 KV55 Lite without Hall.
- Exact ratio: 8:1; sun 15T, planets 45T, fixed ring 105T.
- The toothed stage and planet bearings are inside the nominal motor bore/stack.
  Joint bearings and covers extend axially outside it.
- 119 separately named STEP solids; mm units; no native CAD feature history/mates.
- Approximate CAD mass 2.86 kg; envelope diameter140 x length79 mm.
- Provisional motor command ceiling6 Nm; about45.12 Nm output only if eta=.94.
  The OEM12 Nm peak is not a qualified gearbox rating.
- Reference-pose checks: all solids valid; zero positive-volume intersections.
  Gear motion: five sampled positions, not a continuous motion proof.

## Important open items

The OEM PDF shows28 mm, but the supplied OEM STEP contains46 open shells and a
31.5 mm axial extent. Confirm the selected motor/lead/winding envelope with CubeMars.
The delivered motor parts are dimension envelopes, not repaired OEM solids.

Production tooth-root fillets, fatigue allowables, full FEA, bearing fits,
certified heat treatment, insert anchorage, sealing, electrical integration,
measured cooling and duty-cycle validation remain open. The calculated sun
bending/torsion screen has only about1.48 conditional reserve at the provisional
6 Nm point under the stated multipliers. That is not a certified service rating.
Current limiting does not protect against externally imposed backdrive impacts.

## Reproduction

Tested with CadQuery2.7.0 / Python3.12.
Additional report/preview packages: NumPy, Pillow, ReportLab.
The report generator expects DejaVu font files at the Linux system font path;
change those paths for Windows/macOS. The CAD generator needs no renderer.

    python build_actuator.py
    python calculations.py
    python validate_geometry.py
    g++ -O3 raster.cpp -o raster
    python render_software.py
    python make_report.py

Run commands in the extracted folder. The generator writes beside its source.
Read the report's source register for original manufacturer references.

## Contents

RO100_QDD8_assembly.step              Named mechanical assembly
RO100_QDD8_design_report.pdf          Theory, assumptions, calculations, release gates
RO100_QDD8_design_report.md           Searchable report text
build_actuator.py                    Parametric CadQuery source
calculations.py / calculations.json  Reproducible engineering screens
validate_geometry.py / validation.json  Geometry checks and final results
parts.json                          Exact119-part list, approximate masses and notes
assembly_preview.png                Exterior CAD rendering
gearbox_cutaway.png                  Gear train with covers removed
render_software.py / raster.cpp      Reproducible CPU CAD preview renderer
make_report.py                      Report generator
references/RO100-LITE-KV55.pdf        Original manufacturer drawing
references/RO100-KV55-lite.STEP       Original unmodified open-shell OEM CAD
